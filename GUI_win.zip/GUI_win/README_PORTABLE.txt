GDDAQ-CAEN external ROOT package

Package: gddaq_portable_20260829_170454_external_root
Created: 2026-08-29 17:05:10

Requirements
- 64-bit ROOT 6.26.14 for Windows, built with a compatible Microsoft Visual C++ toolchain
- CAEN hardware drivers required by the connected digitizer

How to run
1. Install ROOT 6.26.14 on the target PC.
2. Copy this whole GDDAQ folder to the target PC.
3. Double-click Run_GDDAQ.bat.
4. On first run, enter the ROOT installation directory, for example:
   C:\root_v6.26.14
5. The selected path is saved in root_path.txt and reused next time.

To change ROOT later
- Double-click Set_ROOT_Path.bat, or delete root_path.txt and run GDDAQ again.
- You can also run: Run_GDDAQ.bat "C:\root_v6.26.14"

GDDAQ login
   user: admin
   password: admin

ROOT HTTP page
   http://127.0.0.1:8765/

Notes
- This package intentionally does not contain a root directory.
- Using a different ROOT release may cause DLL or ABI compatibility errors.
- Runtime messages are printed directly in the terminal window.
