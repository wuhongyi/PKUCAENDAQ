@echo off
setlocal

set "APPDIR=%~dp0"
set "NEW_ROOT="

echo Configure ROOT for GDDAQ
echo.
echo Enter the ROOT installation directory.
echo Example: C:\root_v6.26.14
echo.
set /p "NEW_ROOT=ROOT path: "
set "NEW_ROOT=%NEW_ROOT:"=%"

if not defined NEW_ROOT (
  echo ERROR: No ROOT path was entered.
  pause
  exit /b 1
)

if not exist "%NEW_ROOT%\bin\libCore.dll" (
  echo ERROR: libCore.dll was not found in "%NEW_ROOT%\bin".
  pause
  exit /b 1
)

if not exist "%NEW_ROOT%\bin\libRHTTPSniff.dll" (
  echo ERROR: libRHTTPSniff.dll was not found in "%NEW_ROOT%\bin".
  pause
  exit /b 1
)

if not exist "%NEW_ROOT%\include\Rtypes.h" (
  echo ERROR: ROOT headers were not found in "%NEW_ROOT%\include".
  pause
  exit /b 1
)

> "%APPDIR%root_path.txt" echo %NEW_ROOT%
echo.
echo ROOT path saved: %NEW_ROOT%
echo You can now start GDDAQ with Run_GDDAQ.bat.
pause
