@echo off
setlocal

set "APPDIR=%~dp0"

if not "%~1"=="" set "ROOTSYS=%~1"
if not defined ROOTSYS if exist "%APPDIR%root_path.txt" set /p ROOTSYS=<"%APPDIR%root_path.txt"

if not defined ROOTSYS goto configure_root
if not exist "%ROOTSYS%\bin\libCore.dll" goto configure_root
if not exist "%ROOTSYS%\bin\libRHTTPSniff.dll" goto configure_root
if not exist "%ROOTSYS%\include\Rtypes.h" goto configure_root
goto root_ready

:configure_root
echo ROOT is not configured or the configured path is invalid.
echo.
call "%APPDIR%Set_ROOT_Path.bat"
if errorlevel 1 exit /b 1
set "ROOTSYS="
set /p ROOTSYS=<"%APPDIR%root_path.txt"

:root_ready
set "ROOT_INCLUDE_PATH=%ROOTSYS%\include"
set "PATH=%APPDIR%;%APPDIR%caen;%ROOTSYS%\bin;%PATH%"

cd /d "%APPDIR%"

echo GDDAQ launch - external ROOT package
echo Time: %DATE% %TIME%
echo APPDIR=%APPDIR%
echo ROOTSYS=%ROOTSYS%
echo ROOT_INCLUDE_PATH=%ROOT_INCLUDE_PATH%
echo.

if not exist "%APPDIR%gddaq.exe" (
  echo ERROR: gddaq.exe was not found.
  pause
  exit /b 1
)

if not exist "%APPDIR%CAEN_FELib.dll" (
  echo ERROR: CAEN_FELib.dll was not found.
  pause
  exit /b 1
)

echo Starting gddaq.exe...
echo.
"%APPDIR%gddaq.exe" 2>&1
set "EXITCODE=%ERRORLEVEL%"

echo.
echo Program exited with code %EXITCODE%.
pause
