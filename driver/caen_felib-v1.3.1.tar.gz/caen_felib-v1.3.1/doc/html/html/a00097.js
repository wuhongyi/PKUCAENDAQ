var a00097 =
[
    [ "Error", "a00126.html", "a00126" ],
    [ "ErrorCode", "a00122.html", null ]
];