var files_dup =
[
    [ "include", "dir_d44c64559bbebec7f509842c48db8b23.html", "dir_d44c64559bbebec7f509842c48db8b23" ],
    [ "python", "dir_7837fde3ab9c1fb2fc5be7b717af8d79.html", "dir_7837fde3ab9c1fb2fc5be7b717af8d79" ],
    [ "CHANGELOG", "a00038.html", null ],
    [ "COPYING", "a00044.html", null ],
    [ "COPYING.LESSER", "a00047.html", null ],
    [ "INSTALL", "a00041.html", null ]
];