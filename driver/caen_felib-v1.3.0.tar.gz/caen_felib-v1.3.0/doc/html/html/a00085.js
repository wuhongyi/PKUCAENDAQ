var a00085 =
[
    [ "_DataField", "a00089.html", null ],
    [ "name", "a00085.html#ab74e6bf80237ddc4109968cedc58c151", null ],
    [ "type", "a00085.html#a7aead736a07eaf25623ad7bfa1f0ee2d", null ],
    [ "dim", "a00085.html#ae6fa959b9e8f9c638e0d82bf2c7dc5e7", null ],
    [ "shape", "a00085.html#a45cde9abb508c62d67c3bb2b9bf566a5", null ],
    [ "dtype", "a00085.html#acfe99d230e216901bd782cc580e4e815", null ],
    [ "value", "a00085.html#afcc7a4b78ecd8fa7e713f8cfa0f51017", null ],
    [ "proxy_value_2d", "a00085.html#ad31978c10c628def64129daace14e957", null ],
    [ "arg", "a00085.html#abd0cede0b01ebe4b42650abb9b14c3c2", null ]
];