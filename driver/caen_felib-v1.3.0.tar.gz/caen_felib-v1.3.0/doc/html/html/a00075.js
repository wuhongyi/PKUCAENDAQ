var a00075 =
[
    [ "_Data", "a00085.html", "a00085" ],
    [ "Node", "a00097.html", "a00097" ],
    [ "NodeType", "a00093.html", null ],
    [ "connect", "a00075.html#ae009c684027df9726ef036fe0ca5ccaa", null ],
    [ "_type_map", "a00075.html#a5934e9d9143fbd78bbb077d34aba7eb3", null ]
];