var searchData=
[
  ['install_0',['INSTALL',['../a00041.html',1,'']]],
  ['install_2emd_1',['INSTALL.md',['../a00035.html',1,'']]]
];
