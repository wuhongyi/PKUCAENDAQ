var searchData=
[
  ['pychangelog_0',['PYCHANGELOG',['../a00065.html',1,'']]],
  ['python_2fdoc_2fintroduction_2emd_1',['INTRODUCTION.md',['../a00254.html',1,'']]]
];
