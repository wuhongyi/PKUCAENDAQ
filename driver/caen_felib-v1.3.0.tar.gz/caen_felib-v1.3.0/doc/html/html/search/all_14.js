var searchData=
[
  ['website_0',['Website',['../index.html#autotoc_md27',1,'']]],
  ['windows_1',['windows',['../a00247.html#autotoc_md3',1,'Windows'],['../a00248.html#autotoc_md23',1,'Windows']]],
  ['with_20a_20device_2',['Interact with a device',['../a00247.html#autotoc_md14',1,'']]]
];
