var searchData=
[
  ['python_0',['Python',['../a00072.html',1,'']]]
];
