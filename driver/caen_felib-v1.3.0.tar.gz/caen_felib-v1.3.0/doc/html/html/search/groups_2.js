var searchData=
[
  ['macros_0',['macros',['../a00068.html',1,'Utility macros'],['../a00069.html',1,'Version macros']]]
];
