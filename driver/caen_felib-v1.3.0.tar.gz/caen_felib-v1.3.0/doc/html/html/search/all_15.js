var searchData=
[
  ['your_20project_0',['Compile your project',['../a00247.html#autotoc_md0',1,'']]],
  ['your_20software_1',['Develop your software',['../a00247.html#autotoc_md5',1,'']]]
];
