var searchData=
[
  ['utility_20macros_0',['Utility macros',['../a00068.html',1,'']]]
];
