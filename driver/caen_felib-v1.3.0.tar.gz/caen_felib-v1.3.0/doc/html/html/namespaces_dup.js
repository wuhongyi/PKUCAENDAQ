var namespaces_dup =
[
    [ "caen_felib", "a00073.html", "a00073" ]
];