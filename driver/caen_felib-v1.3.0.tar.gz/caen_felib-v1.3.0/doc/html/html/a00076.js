var a00076 =
[
    [ "Error", "a00105.html", "a00105" ],
    [ "ErrorCode", "a00101.html", null ]
];