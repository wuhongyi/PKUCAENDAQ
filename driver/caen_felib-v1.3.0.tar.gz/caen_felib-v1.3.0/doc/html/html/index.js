var index =
[
    [ "Description", "index.html#autotoc_md25", [
      [ "Architecture", "index.html#autotoc_md26", null ]
    ] ],
    [ "Website", "index.html#autotoc_md27", null ],
    [ "Language", "index.html#autotoc_md28", null ],
    [ "Copyright notice", "index.html#autotoc_md29", null ],
    [ "Credits", "index.html#credits", null ],
    [ "Disclaimer", "index.html#autotoc_md30", null ]
];