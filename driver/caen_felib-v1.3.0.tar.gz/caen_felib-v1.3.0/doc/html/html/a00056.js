var a00056 =
[
    [ "ErrorCode", "a00101.html", null ],
    [ "Error", "a00105.html", "a00105" ]
];