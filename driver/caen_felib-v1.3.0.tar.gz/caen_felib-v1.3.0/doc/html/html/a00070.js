var a00070 =
[
    [ "CAEN_FELib_ErrorCode", "a00070.html#gaf6fd99dc08cad57510b19e7c35db289b", [
      [ "CAEN_FELib_Success", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289bac989c16cdd820a7aa10b6125212f91f7", null ],
      [ "CAEN_FELib_GenericError", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289ba168cf0f9201caf4b6a3a06c9168a8644", null ],
      [ "CAEN_FELib_InvalidParam", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289ba5b5561f36fa60fe437442e4d72bac2eb", null ],
      [ "CAEN_FELib_DeviceAlreadyOpen", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289ba01f713ab8b7a26973d35e26663521974", null ],
      [ "CAEN_FELib_DeviceNotFound", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289ba8c9296a4be9c3166ec8d5c0ee5eb9715", null ],
      [ "CAEN_FELib_MaxDevicesError", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289baa64e88c5e0c35afc5414fb0413d0fbf4", null ],
      [ "CAEN_FELib_CommandError", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289ba00ed5156e0d736d8625ebfc58d8a75f3", null ],
      [ "CAEN_FELib_InternalError", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289ba9d42d8acaab41cd61f86fb8e5457b772", null ],
      [ "CAEN_FELib_NotImplemented", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289ba0538efb251efaf0d2bcb0b6a4118eea4", null ],
      [ "CAEN_FELib_InvalidHandle", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289ba3d19a97be76ac3ca7af7512bbf9aef53", null ],
      [ "CAEN_FELib_DeviceLibraryNotAvailable", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289badc175ee1fc07a0e08ee43f99ea145c29", null ],
      [ "CAEN_FELib_Timeout", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289ba1ff91063f1b10cd67993bb809b98f9b9", null ],
      [ "CAEN_FELib_Stop", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289baa1f0a67aa5e6376c5a3be64d4251f502", null ],
      [ "CAEN_FELib_Disabled", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289ba2222a5b5bbae78406dd85ed41a16d17f", null ],
      [ "CAEN_FELib_BadLibraryVersion", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289bace9fa0f5ec1469682f5cf1c8b1a03561", null ],
      [ "CAEN_FELib_CommunicationError", "a00070.html#ggaf6fd99dc08cad57510b19e7c35db289ba0d6515462b91a2f1539d6802e4cdcb8c", null ]
    ] ],
    [ "CAEN_FELib_NodeType_t", "a00070.html#ga31dbb3152738db516706309bdb0bc3ce", [
      [ "CAEN_FELib_UNKNOWN", "a00070.html#gga31dbb3152738db516706309bdb0bc3cea091045f8d64225120a4ab1035e63f2a5", null ],
      [ "CAEN_FELib_PARAMETER", "a00070.html#gga31dbb3152738db516706309bdb0bc3cea1b5ef9ae64959430e6de53d5b3aefdaf", null ],
      [ "CAEN_FELib_COMMAND", "a00070.html#gga31dbb3152738db516706309bdb0bc3cea4937d2876d152a48067d4ca35b92d1a3", null ],
      [ "CAEN_FELib_FEATURE", "a00070.html#gga31dbb3152738db516706309bdb0bc3ceac47ced32194e41cf6096065f219c3dc3", null ],
      [ "CAEN_FELib_ATTRIBUTE", "a00070.html#gga31dbb3152738db516706309bdb0bc3cea10c8e01a038c12a020ab56f6ee661bfc", null ],
      [ "CAEN_FELib_ENDPOINT", "a00070.html#gga31dbb3152738db516706309bdb0bc3ceafd75aca35df8fb0dffbebb3858c5ed04", null ],
      [ "CAEN_FELib_CHANNEL", "a00070.html#gga31dbb3152738db516706309bdb0bc3cea64250697f7d013e4df8e6a5827c3294b", null ],
      [ "CAEN_FELib_DIGITIZER", "a00070.html#gga31dbb3152738db516706309bdb0bc3cea6d797228321f40c86ce4795bb1df153a", null ],
      [ "CAEN_FELib_FOLDER", "a00070.html#gga31dbb3152738db516706309bdb0bc3ceabe9775a1717c3830de878fa2ebdc2a2a", null ],
      [ "CAEN_FELib_LVDS", "a00070.html#gga31dbb3152738db516706309bdb0bc3cea2e69bdbb9e877726cea5fa757ab1a280", null ],
      [ "CAEN_FELib_VGA", "a00070.html#gga31dbb3152738db516706309bdb0bc3cea7dba1e76a47ba995654bf6c5795041c2", null ],
      [ "CAEN_FELib_HV_CHANNEL", "a00070.html#gga31dbb3152738db516706309bdb0bc3cea094b609cb96325b2ca3ef76e4be91f5b", null ],
      [ "CAEN_FELib_MONOUT", "a00070.html#gga31dbb3152738db516706309bdb0bc3ceabfaad21fc60a54d1effc48289d6a3a1a", null ],
      [ "CAEN_FELib_VTRACE", "a00070.html#gga31dbb3152738db516706309bdb0bc3ceac989827675dcf9d16c15717e01fbcf8c", null ],
      [ "CAEN_FELib_GROUP", "a00070.html#gga31dbb3152738db516706309bdb0bc3ceab64d6ba36cda48a2c2f8d51f7a1db2c0", null ],
      [ "CAEN_FELib_HV_RANGE", "a00070.html#gga31dbb3152738db516706309bdb0bc3cead5225a2d5ee6a9a10d781d8d9cf7ce69", null ]
    ] ]
];