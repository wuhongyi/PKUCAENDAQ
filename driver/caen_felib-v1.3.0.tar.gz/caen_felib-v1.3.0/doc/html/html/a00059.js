var a00059 =
[
    [ "_Data", "a00085.html", "a00085" ],
    [ "_Data._DataField", "a00089.html", null ],
    [ "NodeType", "a00093.html", null ],
    [ "Node", "a00097.html", "a00097" ],
    [ "connect", "a00059.html#ae009c684027df9726ef036fe0ca5ccaa", null ],
    [ "_type_map", "a00059.html#a5934e9d9143fbd78bbb077d34aba7eb3", null ]
];