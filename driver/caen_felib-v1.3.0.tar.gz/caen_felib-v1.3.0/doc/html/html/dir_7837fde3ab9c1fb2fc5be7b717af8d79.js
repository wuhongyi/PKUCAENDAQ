var dir_7837fde3ab9c1fb2fc5be7b717af8d79 =
[
    [ "doc", "dir_54cfbf4dc097e36ab9019cfff8466d0b.html", null ],
    [ "src", "dir_f5914bd29df15049ae416e8a0eac21ca.html", "dir_f5914bd29df15049ae416e8a0eac21ca" ],
    [ "PYCHANGELOG", "a00065.html", null ]
];