var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvw",
  1: "_dehlmn",
  2: "c",
  3: "_cdeilp",
  4: "acghilnoprstv",
  5: "abcdefghilmnoprstuvw",
  6: "c",
  7: "c",
  8: "aepuv",
  9: "cilps"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules",
  9: "Pages"
};

