var searchData=
[
  ['utility_20macros_0',['Utility macros',['../a00098.html',1,'']]]
];
