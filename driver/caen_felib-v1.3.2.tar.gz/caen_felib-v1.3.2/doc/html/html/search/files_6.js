var searchData=
[
  ['introduction_2emd_0',['INTRODUCTION.md',['../a00312.html',1,'']]],
  ['pychangelog_1',['PYCHANGELOG',['../a00092.html',1,'']]]
];
