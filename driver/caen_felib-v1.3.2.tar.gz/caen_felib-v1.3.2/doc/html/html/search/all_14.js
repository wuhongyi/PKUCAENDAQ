var searchData=
[
  ['wave_5fon_5fext_5finhibit_0',['WAVE_ON_EXT_INHIBIT',['../a00158.html#a6586c44de128d46218f0eb5039e724df',1,'caen_felib::dig2_types::LowPriorityFlags']]],
  ['wave_5fover_5fsaturation_1',['WAVE_OVER_SATURATION',['../a00158.html#a1d66a7521d3c6c2c6b4904d180403839',1,'caen_felib::dig2_types::LowPriorityFlags']]],
  ['wave_5funder_5fsaturation_2',['WAVE_UNDER_SATURATION',['../a00158.html#ad1ab8b2dfd96e576310a79f1a48b9082',1,'caen_felib::dig2_types::LowPriorityFlags']]]
];
