var a00104 =
[
    [ "Manager", "a00114.html", "a00114" ],
    [ "cached", "a00104.html#ad74fa41e6b4bbea4e3c7e5ba88ffccf9", null ],
    [ "clear", "a00104.html#a25c607b4bb0e9b466f127c0668b02a1b", null ]
];