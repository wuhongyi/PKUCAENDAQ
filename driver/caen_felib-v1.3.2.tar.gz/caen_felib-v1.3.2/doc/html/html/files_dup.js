var files_dup =
[
    [ "CHANGELOG", "a00056.html", null ],
    [ "COPYING", "a00062.html", null ],
    [ "COPYING.LESSER", "a00065.html", null ],
    [ "CAEN_FELib.h", "a00041.html", "a00041" ],
    [ "INSTALL", "a00059.html", null ],
    [ "PYCHANGELOG", "a00092.html", null ],
    [ "__init__.py", "a00068.html", "a00068" ],
    [ "_cache.py", "a00080.html", "a00080" ],
    [ "_utils.py", "a00071.html", "a00071" ],
    [ "device.py", "a00083.html", "a00083" ],
    [ "dig1_types.py", "a00074.html", [
      [ "DppProbeType", "a00134.html", null ],
      [ "DppFlags", "a00138.html", null ]
    ] ],
    [ "dig2_types.py", "a00086.html", [
      [ "DppAnalogProbeType", "a00142.html", null ],
      [ "DppDigitalProbeType", "a00146.html", null ],
      [ "HighPriorityFlagsPha", "a00150.html", null ],
      [ "HighPriorityFlagsPsd", "a00154.html", null ],
      [ "LowPriorityFlags", "a00158.html", null ]
    ] ],
    [ "error.py", "a00077.html", [
      [ "ErrorCode", "a00162.html", null ],
      [ "Error", "a00166.html", "a00166" ]
    ] ],
    [ "lib.py", "a00089.html", [
      [ "_Lib", "a00170.html", "a00170" ]
    ] ]
];