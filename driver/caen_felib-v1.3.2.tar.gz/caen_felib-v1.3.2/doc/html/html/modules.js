var modules =
[
    [ "Utility macros", "a00098.html", "a00098" ],
    [ "Version macros", "a00099.html", "a00099" ],
    [ "Enumerations", "a00100.html", "a00100" ],
    [ "API", "a00101.html", "a00101" ],
    [ "Python", "a00102.html", "a00102" ]
];