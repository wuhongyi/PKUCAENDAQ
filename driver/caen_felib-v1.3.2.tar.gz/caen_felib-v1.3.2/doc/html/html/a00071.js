var a00071 =
[
    [ "Lib", "a00118.html", "a00118" ],
    [ "version_to_tuple", "a00071.html#ad70ade103cacdf39a3006cac13b9e106", null ],
    [ "to_bytes", "a00071.html#ab3c4a072e66624608c30672356fce6ee", null ],
    [ "to_bytes_opt", "a00071.html#ac33f19d99e0c7c216e189c440b484566", null ],
    [ "to_bytes_opt", "a00071.html#a3a2c910eabab0520a2638c4d02927018", null ],
    [ "to_bytes_opt", "a00071.html#a8dcab3bcb2411831531c34b0c69d42a5", null ],
    [ "dataclass_slots", "a00071.html#a4313dd57de34b08c5677cffb6001b479", null ],
    [ "dataclass_slots_weakref", "a00071.html#a5ed1673b2ecdf23727eb5e44dd8c6f48", null ]
];